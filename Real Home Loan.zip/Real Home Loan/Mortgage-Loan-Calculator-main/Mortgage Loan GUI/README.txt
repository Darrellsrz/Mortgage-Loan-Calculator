Things should be installed in command prompt / system shell :
pip install openpyxl
pip install Pillow
pip install pathlib
